# Chat Discrimination Preventor

Out of the box solution to make game chats a safer and nicer place. A tool powered by AI to detect discrimination and hate-speech and encourage emphatetic messages.

This package classifies if a message contains, for example, identity attacks, toxicity and sexual attacks and 
advice messages to help users behave differently.

It also classifies if a message is positive and returns a positive message with the detection to encourage positive behaviour.